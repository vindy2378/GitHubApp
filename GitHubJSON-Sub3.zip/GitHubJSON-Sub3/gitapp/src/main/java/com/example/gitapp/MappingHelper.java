package com.example.gitapp;

import android.database.Cursor;

import com.example.gitapp.db.UserDbContract;
import com.example.gitapp.model.UserGithub;

import java.util.ArrayList;

public class MappingHelper {

    public static ArrayList<UserGithub> mapCursorToArrayList(Cursor notesCursor) {
        ArrayList<UserGithub> notesList = new ArrayList<>();

        while (notesCursor.moveToNext()) {
            int id = notesCursor.getInt(notesCursor.getColumnIndexOrThrow(UserDbContract.UserColumns._ID));
            String login = notesCursor.getString(notesCursor.getColumnIndexOrThrow(UserDbContract.UserColumns.USERNAME));
            String url = notesCursor.getString(notesCursor.getColumnIndexOrThrow(UserDbContract.UserColumns.URL));
            String avatar = notesCursor.getString(notesCursor.getColumnIndexOrThrow(UserDbContract.UserColumns.AVATAR));
            notesList.add(new UserGithub(notesCursor));
        }

        return notesList;
    }

    public static UserGithub mapCursorToObject(Cursor notesCursor) {
        notesCursor.moveToFirst();
        int id = notesCursor.getInt(notesCursor.getColumnIndexOrThrow(UserDbContract.UserColumns._ID));
        String login = notesCursor.getString(notesCursor.getColumnIndexOrThrow(UserDbContract.UserColumns.USERNAME));
        String url = notesCursor.getString(notesCursor.getColumnIndexOrThrow(UserDbContract.UserColumns.URL));
        String avatar = notesCursor.getString(notesCursor.getColumnIndexOrThrow(UserDbContract.UserColumns.AVATAR));
        return new UserGithub(notesCursor);
    }
}
