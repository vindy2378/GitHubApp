package com.example.githubjson;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.example.githubjson.adapter.ViewPagerAdapter;
import com.example.githubjson.db.UserDbContract;
import com.example.githubjson.db.UserDbHelper;
import com.example.githubjson.db.UserHelper;
import com.example.githubjson.model.UserGithub;
import com.example.githubjson.model.UserGithubDetail;

import com.github.ivbaranov.mfb.MaterialFavoriteButton;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.githubjson.db.UserDbContract.UserColumns.TABLE_USER_NAME;

public class DetailActivity extends AppCompatActivity {

    private TextView repo,follower,following,username,bio,email;
    private ImageView avatar;
    private UserGithub userGithub;
    private ProgressBar progressBar;
    private UserHelper userHelper;
    private ArrayList<UserGithub> userGithubList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        progressBar = findViewById(R.id.progressBar);

        ViewPagerAdapter adapter = new ViewPagerAdapter(this,getSupportFragmentManager());
        TabLayout tabLayout = findViewById(R.id.tab_layout);
        ViewPager viewPager = findViewById(R.id.vp);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.setElevation(0);
        setDataDetailUser();

        setOnClickFavoriteButton();
        userHelper = UserHelper.getInstance(getApplicationContext());


        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle("Detail User " + userGithub.getLogin());
        }
    }


    private void setOnClickFavoriteButton(){
        MaterialFavoriteButton materialFavoriteButton = findViewById(R.id.mfb_favorite);
        if (EXIST(userGithub.getLogin())){
            materialFavoriteButton.setFavorite(true);
            materialFavoriteButton.setOnFavoriteChangeListener(new MaterialFavoriteButton.OnFavoriteChangeListener() {
                @Override
                public void onFavoriteChanged(MaterialFavoriteButton buttonView, boolean favorite) {
                    if (favorite){
                        userGithubList = userHelper.getDataUser();
                        userHelper.userInsert(userGithub);
                        Toast.makeText(DetailActivity.this, "Success added favorite", Toast.LENGTH_SHORT).show();
                    }else {
                        userGithubList = userHelper.getDataUser();
                        userHelper.userDelete(String.valueOf(userGithub.getId()));
                        Toast.makeText(DetailActivity.this, "Success delete favorite", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }else {
            materialFavoriteButton.setOnFavoriteChangeListener(new MaterialFavoriteButton.OnFavoriteChangeListener() {
                @Override
                public void onFavoriteChanged(MaterialFavoriteButton buttonView, boolean favorite) {
                    if (favorite){
                        userGithubList = userHelper.getDataUser();
                        userHelper.userInsert(userGithub);
                        Toast.makeText(DetailActivity.this, "Success added favorite", Toast.LENGTH_SHORT).show();
                    }else {
                        userGithubList = userHelper.getDataUser();
                        userHelper.userDelete(String.valueOf(userGithub.getId()));
                        Toast.makeText(DetailActivity.this, "Success delete favorite", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
    private boolean EXIST(String username){
        String change = UserDbContract.UserColumns.USERNAME + "=?";
        String[] changeArg = {username};
        String limit = "1";
        userHelper = new UserHelper(this);
        userHelper.open();
        userGithub = getIntent().getParcelableExtra("DATA_USER");

        UserDbHelper userDbHelper = new UserDbHelper(getApplicationContext());
        SQLiteDatabase database = userDbHelper.getWritableDatabase();
        @SuppressLint("Recycle") Cursor cursor = database.query(TABLE_USER_NAME,null,change,changeArg,null,null,null,limit);
        boolean exist = (cursor.getCount() > 0 );
        cursor.close();
        return exist;
    }

    private void setDataDetailUser(){
        progressBar.setVisibility(View.VISIBLE);
        userGithub = getIntent().getParcelableExtra("DATA_USER");
        if (userGithub != null){
            repo = findViewById(R.id.tv_repo);
            follower = findViewById(R.id.tv_followers);
            following = findViewById(R.id.tv_following);
            username = findViewById(R.id.tv_username);
            bio = findViewById(R.id.tv_bio);
            email = findViewById(R.id.tv_email);
            avatar = findViewById(R.id.image_user_detail);

            final LinearLayout linearLayout = findViewById(R.id.linear_layout);
            ApiService apiService = RetrofitConfiguration.getRetrofit().create(ApiService.class);
            Call<UserGithubDetail> call = apiService.getUserDetail(userGithub.getLogin());
            call.enqueue(new Callback<UserGithubDetail>() {
                @Override
                public void onResponse(Call<UserGithubDetail> call, Response<UserGithubDetail> response) {
                    if (response.body() != null){
                        repo.setText(String.valueOf(response.body().getPublicRepos()));
                        follower.setText(String.valueOf(response.body().getFollowers()));
                        following.setText(String.valueOf(response.body().getFollowing()));
                        username.setText(response.body().getName());
                        bio.setText(response.body().getBio());
                        email.setText(response.body().getEmail());
                        Glide.with(getApplicationContext())
                                .load(response.body().getAvatarUrl())
                                .into(avatar);
                        username.setVisibility(View.VISIBLE);
                        bio.setVisibility(View.VISIBLE);
                        email.setVisibility(View.VISIBLE);
                        avatar.setVisibility(View.VISIBLE);
                        linearLayout.setVisibility(View.VISIBLE);
                        progressBar.setVisibility(View.INVISIBLE);

                    }
                }

                @Override
                public void onFailure(Call<UserGithubDetail> call, Throwable t) {

                }
            });
        }
    }
}
