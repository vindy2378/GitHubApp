package com.example.githubjson;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.githubjson.adapter.AdapterSearch;
import com.example.githubjson.adapter.AdapterUser;
import com.example.githubjson.model.ResponseSearch;
import com.example.githubjson.model.UserGithub;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvUsers;
    private android.widget.SearchView sv;
    private ArrayList<UserGithub> listUser = new ArrayList<>();

    private RecyclerView rvUsersFollower;
    private ArrayList<UserGithub> listUserFollower = new ArrayList<>();

    private String title = "Github User Data";
    private ProgressBar progressBar;
    private String userFollower;
    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressBar = findViewById(R.id.progressBar);

        rvUsers = findViewById(R.id.rv_user);
        rvUsers.setHasFixedSize(true);
        rvUsers.setLayoutManager(new LinearLayoutManager(this));

        AmbilUser();

        setActionBarTitle(title);
        rvUsers.setLayoutManager(new LinearLayoutManager(this));

    }


    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu1:
                //AmbilUser();
                Intent ii = new Intent(this, AlarmActivity.class);
                startActivity(ii);
                return true;
            case R.id.menu2:
                Intent i = new Intent(this, FavActivity.class);
                startActivity(i);
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);

        if (searchManager != null) {
            SearchView searchView = (SearchView) (menu.findItem(R.id.search)).getActionView();
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
            searchView.setQueryHint(getResources().getString(R.string.search_hint));
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    CariUser(query);
                    return true;
                }
                @Override
                public boolean onQueryTextChange(String newText) {
                    return false;
                }
            });
        }
        else
        {
            //getUsers();
        }
        return true;
    }


    private void AmbilUser(){
        progressBar.setVisibility(View.VISIBLE);
        ApiService apiService = RetrofitConfiguration.getRetrofit().create(ApiService.class);
        Call<List<UserGithub>> call = apiService.getGithubUser("01e4183d7b7f9f1c422eb235d83676a8347bca08");
        call.enqueue(new Callback<List<UserGithub>>() {
            @Override
            public void onResponse(Call<List<UserGithub>> call, Response<List<UserGithub>> response) {
                progressBar.setVisibility(View.INVISIBLE);
                AdapterUser adapterUser = new AdapterUser(getApplicationContext(),response.body());
                rvUsers.setAdapter(adapterUser);
            }

            @Override
            public void onFailure(Call<List<UserGithub>> call, Throwable t) {

            }
        });
    }

    private void CariUser(String username){
        progressBar.setVisibility(View.VISIBLE);
        ApiService apiService = RetrofitConfiguration.getRetrofit().create(ApiService.class);
        Call<ResponseSearch> call = apiService.getGithubSearch(username);
        call.enqueue(new Callback<ResponseSearch>() {
            @Override
            public void onResponse(Call<ResponseSearch> call, Response<ResponseSearch> response) {
                progressBar.setVisibility(View.INVISIBLE);
                if (response.body() != null){
                    AdapterSearch adapterSearch = new AdapterSearch(response.body().getItems());
                    rvUsers.setAdapter(adapterSearch);
                }
            }

            @Override
            public void onFailure(Call<ResponseSearch> call, Throwable t) {

            }
        });
    }


    private void showSelectedUser(UserGithub user) {
        Toast.makeText(this, "Kamu memilih " + user.getLogin(), Toast.LENGTH_SHORT).show();
    }
}