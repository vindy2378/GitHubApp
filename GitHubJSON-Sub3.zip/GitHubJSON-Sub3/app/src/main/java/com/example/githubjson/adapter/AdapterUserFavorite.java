package com.example.githubjson.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.githubjson.model.UserGithub;
import com.example.githubjson.R;
import com.example.githubjson.DetailActivity;

import java.util.ArrayList;
import java.util.List;

public class AdapterUserFavorite extends RecyclerView.Adapter<AdapterUserFavorite.UserViewHolder> {
    private Context c;
    //private ArrayList<UserGithub> userGithubList ;
    private List<UserGithub> userGithubList ;

    /*public AdapterUserFavorite(ArrayList<UserGithub> list) {
        this.userGithubList = list;
    }*/

    public AdapterUserFavorite(Context c, List<UserGithub> userGithubList) {
        this.c = c;
        this.userGithubList = userGithubList;
    }

    public void setUserGithubList(ArrayList<UserGithub> userGithubArrayList){
        this.userGithubList = userGithubArrayList;
    }

    @NonNull
    @Override
    public AdapterUserFavorite.UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user,parent,false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterUserFavorite.UserViewHolder holder, int position) {
        UserGithub userGithub = userGithubList.get(position);
        holder.tv_name.setText(userGithub.getLogin());
        holder.tv_url.setText(userGithub.getHtmlUrl());
        Glide.with(holder.itemView.getContext())
                .load(userGithub.getAvatarUrl())
                .into(holder.img);
    }

    @Override
    public int getItemCount() {
        return userGithubList.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView img;
        TextView tv_url,tv_name;
        UserViewHolder(@NonNull View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.img_user);
            tv_name = itemView.findViewById(R.id.tv_name);
            tv_url = itemView.findViewById(R.id.tv_url);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            UserGithub userGithub = userGithubList.get(getAdapterPosition());
            Intent intent = new Intent(c, DetailActivity.class);
            intent.putExtra("DATA_USER",userGithub);
            v.getContext().startActivity(intent);
        }
    }
}
