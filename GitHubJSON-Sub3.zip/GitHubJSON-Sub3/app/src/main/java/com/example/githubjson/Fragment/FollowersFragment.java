package com.example.githubjson.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.githubjson.adapter.AdapterUser;
import com.example.githubjson.ApiService;
import com.example.githubjson.RetrofitConfiguration;
import com.example.githubjson.model.UserGithub;
import com.example.githubjson.R;

import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 created at  5 may 2020;
 by makhalibagas
 */
public class FollowersFragment extends Fragment {

    private RecyclerView recyclerView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_followers, container, false);
        setDataFollowers(view);
        return view;
    }

    private void setDataFollowers(View view){
        recyclerView = view.findViewById(R.id.rv_user);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        UserGithub userGithub = Objects.requireNonNull(getActivity()).getIntent().getParcelableExtra("DATA_USER");
        ApiService apiService = RetrofitConfiguration.getRetrofit().create(ApiService.class);
        Call<List<UserGithub>> call = apiService.getUserFollowers(Objects.requireNonNull(userGithub).getLogin());
        call.enqueue(new Callback<List<UserGithub>>() {
            @Override
            public void onResponse(Call<List<UserGithub>> call, Response<List<UserGithub>> response) {
                AdapterUser adapterUser = new AdapterUser(getContext(),response.body());
                recyclerView.setAdapter(adapterUser);

            }

            @Override
            public void onFailure(Call<List<UserGithub>> call, Throwable t) {

            }
        });
    }
}
