package com.example.githubjson;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import com.example.githubjson.adapter.AdapterUserFavorite;
import com.example.githubjson.db.UserHelper;
import com.example.githubjson.model.UserGithub;

import java.util.ArrayList;


public class FavActivity extends AppCompatActivity {
    private RecyclerView rvUsers;
    private String title = "Github Favorite User";
    private UserHelper userHelper;
    private ArrayList<UserGithub> userGithubList =  new ArrayList<>();
    private AdapterUserFavorite adapterUserFavorite;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav);
        progressBar = findViewById(R.id.progressBar);
        setActionBarTitle(title);

        progressBar.setVisibility(View.VISIBLE);

        userHelper = new UserHelper(getApplicationContext());
        userHelper.open();
        userGithubList = userHelper.getDataUser();

        rvUsers = findViewById(R.id.rv_user_fav);
        rvUsers.setHasFixedSize(true);
        rvUsers.setLayoutManager(new LinearLayoutManager(this));
        AdapterUserFavorite listUserAdapter = new AdapterUserFavorite(this,userGithubList);
        rvUsers.setAdapter(listUserAdapter);

        progressBar.setVisibility(View.INVISIBLE);


    }

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    /*private void setRecyclerView(){
        RecyclerView rv = findViewById(R.id.rv_user_fav);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setHasFixedSize(true);
        adapterUserFavorite = new AdapterUserFavorite(getApplicationContext());
        rv.setAdapter(adapterUserFavorite);

    }*/

    /*@Override
    protected void onResume() {
        super.onResume();
        userGithubList = userHelper.getDataUser();
        adapterUserFavorite.setUserGithubList(userGithubList);
    }*/

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userHelper.close();
    }

}